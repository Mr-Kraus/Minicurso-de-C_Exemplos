import asyncio
import sys

def encrypt(message, key):
    shift = sum(ord(c) for c in key) % 256
    return ''.join(chr((ord(c)+shift)%256) for c in message)

def print_message(msg):
    sys.stdout.write('\r' + ' ' * 80 + '\r')
    print(msg)
    sys.stdout.write('> ')
    sys.stdout.flush()

async def reader_task(reader, queue):
    while True:
        try:
            data = await reader.readline()
            if not data:
                await queue.put("CTRL:Conexão encerrada pelo servidor")
                break
            await queue.put(data.decode().strip())
        except Exception as e:
            await queue.put(f"CTRL:Erro ao receber: {e}")
            break

async def message_handler(queue):
    while True:
        msg = await queue.get()
        if msg is None:
            break
        print_message(msg)

async def user_input(writer, key):
    loop = asyncio.get_event_loop()
    while True:
        msg = await loop.run_in_executor(None, input, "> ")

        if msg.startswith("\\"):
            # Comando especial: enviar sem criptografia
            writer.write((msg + "\n").encode('utf-8'))  # MANTER a barra
            await writer.drain()
            if msg.lower() == "\\exit":
                writer.close()
                await writer.wait_closed()
                break
        else:
            # Mensagem normal: criptografada
            writer.write((encrypt(msg, key) + "\n").encode('utf-8'))
            await writer.drain()

async def main():
    server_ip = input("IP do servidor: ")
    key = input("Palavra-chave fixa: ")

    try:
        reader, writer = await asyncio.open_connection(server_ip, 9000)
    except Exception as e:
        print(f"Erro ao conectar: {e}")
        return

    # Solicita nome do cliente
    data = await reader.readline()
    print(data.decode().strip())
    name = input("Digite seu nome: ")
    writer.write((name + "\n").encode('utf-8'))
    await writer.drain()

    # Cria fila e tasks
    queue = asyncio.Queue()
    recv_task = asyncio.create_task(reader_task(reader, queue))
    handler_task = asyncio.create_task(message_handler(queue))
    input_task = asyncio.create_task(user_input(writer, key))

    # Aguarda tasks
    done, pending = await asyncio.wait(
        [recv_task, handler_task, input_task],
        return_when=asyncio.FIRST_COMPLETED
    )

    # Finaliza tasks restantes
    for task in pending:
        task.cancel()
    await queue.put(None)

asyncio.run(main())
